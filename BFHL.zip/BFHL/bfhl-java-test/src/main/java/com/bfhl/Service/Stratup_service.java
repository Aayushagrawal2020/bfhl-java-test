package com.bfhl.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.annotation.PostConstruct;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

@Service
public class StartupService {

    private final RestTemplate restTemplate = new RestTemplate();
    private final ObjectMapper objectMapper = new ObjectMapper();

    private final String registrationNumber = "REG12347"; // your regNo here

    @PostConstruct
    public void onStartup() {
        try {
            // Step 1: Send POST to generate webhook
            String generateUrl = "https://bfhldevapigw.healthrx.co.in/hiring/generateWebhook/JAVA";

            Map<String, String> requestBody = new HashMap<>();
            requestBody.put("name", "John Doe");
            requestBody.put("regNo", registrationNumber);
            requestBody.put("email", "john@example.com");

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);

            HttpEntity<Map<String, String>> entity = new HttpEntity<>(requestBody, headers);

            ResponseEntity<String> response = restTemplate.postForEntity(generateUrl, entity, String.class);

            JsonNode json = objectMapper.readTree(response.getBody());
            String webhookUrl = json.get("webhook").asText();
            String accessToken = json.get("accessToken").asText();

            // Step 2: Solve SQL problem
            int lastDigit = Integer.parseInt(registrationNumber.replaceAll("[^0-9]", ""));
            int lastTwoDigits = lastDigit % 100;

            String sqlQuery;
            if (lastTwoDigits % 2 == 0) {
                sqlQuery = "SELECT * FROM patients WHERE diabetes = 'yes';"; // Dummy solution for Question 2
            } else {
                sqlQuery = "SELECT * FROM doctors WHERE experience > 5;"; // Dummy solution for Question 1
            }

            // Step 3: Submit answer using JWT
            HttpHeaders authHeaders = new HttpHeaders();
            authHeaders.setContentType(MediaType.APPLICATION_JSON);
            authHeaders.setBearerAuth(accessToken);

            Map<String, String> answer = new HashMap<>();
            answer.put("finalQuery", sqlQuery);

            HttpEntity<Map<String, String>> answerEntity = new HttpEntity<>(answer, authHeaders);
            ResponseEntity<String> result = restTemplate.postForEntity(webhookUrl, answerEntity, String.class);

            System.out.println("Submission Result: " + result.getBody());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
