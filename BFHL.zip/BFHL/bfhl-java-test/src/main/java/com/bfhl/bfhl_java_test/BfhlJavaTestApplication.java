package com.bfhl.bfhl_java_test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BfhlJavaTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(BfhlJavaTestApplication.class, args);
	}

}
